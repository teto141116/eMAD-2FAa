package com.tetocode.contestcodeshare

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.util.regex.Pattern

object NotificationHelper {
    private const val CHANNEL_ID = "contest_code"
    private const val NOTIFICATION_ID = 1001
    private const val EXTRA_VALUE = "value"

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "eMAD 2FA",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "إشعار رمز المسابقة"
            }
            context.getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    fun show(context: Context, link: String) {
        createChannel(context)

        val code = extractCode(link) ?: "—"

        val copyCodeIntent = Intent(context, CopyReceiver::class.java)
            .setAction(CopyReceiver.ACTION_CODE)
            .putExtra(EXTRA_VALUE, code)
        val copyLinkIntent = Intent(context, CopyReceiver::class.java)
            .setAction(CopyReceiver.ACTION_LINK)
            .putExtra(EXTRA_VALUE, link)

        val codePending = PendingIntent.getBroadcast(
            context, 201, copyCodeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val linkPending = PendingIntent.getBroadcast(
            context, 202, copyLinkIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("رمز المسابقة")
            .setContentText(code)
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("الرمز: $code")
            )
            .addAction(0, "نسخ الرمز", codePending)
            .addAction(0, "نسخ رابط المسابقة", linkPending)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(false)
            .build()

        if (Build.VERSION.SDK_INT < 33 ||
            NotificationManagerCompat.from(context).areNotificationsEnabled()
        ) {
            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification)
        }
    }

    private fun extractCode(text: String): String? {
        // Prefer a standalone 6-digit number. If the link contains several,
        // this picks the first one.
        val matcher = Pattern.compile("(?<!\\d)\\d{6}(?!\\d)").matcher(text)
        return if (matcher.find()) matcher.group() else null
    }
}

class CopyReceiver : android.content.BroadcastReceiver() {
    companion object {
        const val ACTION_CODE = "com.tetocode.contestcodeshare.COPY_CODE"
        const val ACTION_LINK = "com.tetocode.contestcodeshare.COPY_LINK"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val value = intent.getStringExtra("value") ?: return
        val label = if (intent.action == ACTION_CODE) "رمز المسابقة" else "رابط المسابقة"

        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText(label, value))
    }
}
