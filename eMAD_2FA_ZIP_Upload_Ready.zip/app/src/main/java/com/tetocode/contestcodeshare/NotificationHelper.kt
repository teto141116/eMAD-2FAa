package com.tetocode.contestcodeshare

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import java.net.URLDecoder
import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets
import java.util.Locale
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

object NotificationHelper {
    private const val CHANNEL_ID = "emad_2fa"
    private const val NOTIFICATION_ID = 1001
    private const val EXTRA_VALUE = "value"

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "eMAD 2FA",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "إشعار رمز التحقق بخطوتين 2FA"
            }
            context.getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    fun show(context: Context, link: String) {
        createChannel(context)

        val code = generateTotpFromLink(link) ?: "—"

        val copyCodeIntent = Intent(context, CopyReceiver::class.java)
            .setAction(CopyReceiver.ACTION_CODE)
            .putExtra(EXTRA_VALUE, code)
        val copyLinkIntent = Intent(context, CopyReceiver::class.java)
            .setAction(CopyReceiver.ACTION_LINK)
            .putExtra(EXTRA_VALUE, link)

        val codePending = PendingIntent.getBroadcast(
            context, 201, copyCodeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val linkPending = PendingIntent.getBroadcast(
            context, 202, copyLinkIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("رمز 2FA")
            .setContentText(code)
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("رمز التحقق: $code")
            )
            .addAction(0, "نسخ الرمز", codePending)
            .addAction(0, "نسخ رابط 2FA", linkPending)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(false)
            .build()

        if (Build.VERSION.SDK_INT < 33 ||
            NotificationManagerCompat.from(context).areNotificationsEnabled()
        ) {
            NotificationManagerCompat.from(context).notify(NOTIFICATION_ID, notification)
        }
    }

    /**
     * Finds a Base32 TOTP secret in a shared 2FA URL/text and generates
     * the current 6-digit RFC 6238 TOTP using the standard SHA-1/30-second
     * parameters used by most authenticator apps.
     */
    private fun generateTotpFromLink(input: String): String? {
        val decoded = try {
            URLDecoder.decode(input, StandardCharsets.UTF_8.name())
        } catch (_: Exception) {
            input
        }

        val secret = findBase32Secret(decoded) ?: return null
        val key = base32Decode(secret) ?: return null
        if (key.isEmpty()) return null

        val counter = System.currentTimeMillis() / 1000L / 30L
        val data = ByteBuffer.allocate(8).putLong(counter).array()

        return try {
            val mac = Mac.getInstance("HmacSHA1")
            mac.init(SecretKeySpec(key, "HmacSHA1"))
            val hash = mac.doFinal(data)
            val offset = hash[hash.size - 1].toInt() and 0x0f
            val binary = ((hash[offset].toInt() and 0x7f) shl 24) or
                ((hash[offset + 1].toInt() and 0xff) shl 16) or
                ((hash[offset + 2].toInt() and 0xff) shl 8) or
                (hash[offset + 3].toInt() and 0xff)
            String.format(Locale.US, "%06d", binary % 1_000_000)
        } catch (_: Exception) {
            null
        }
    }

    private fun findBase32Secret(text: String): String? {
        // First, prefer common 2FA/TOTP query-parameter names.
        val parameterPattern = Regex(
            "(?i)(?:secret|secret_key|otp_secret|totp_secret|totp|otp|key)\\s*[=:]\\s*([A-Z2-7][A-Z2-7\\s-]{15,127})"
        )
        parameterPattern.find(text)?.groupValues?.getOrNull(1)?.let { candidate ->
            val normalized = normalizeBase32(candidate)
            if (isPlausibleBase32(normalized)) return normalized
        }

        // Also support a secret written in groups of four characters, e.g.
        // "mxd2 4tz3 hqs2 uxed 35qu emzu 7xh2 ivae".
        val grouped = Regex("(?i)([A-Z2-7]{4}(?:[ \\t-]+[A-Z2-7]{4}){3,15})")
        grouped.find(text)?.groupValues?.getOrNull(1)?.let { candidate ->
            val normalized = normalizeBase32(candidate)
            if (isPlausibleBase32(normalized)) return normalized
        }

        // Finally support an unspaced Base32 secret such as the 32-character
        // example used by the app.
        val continuous = Regex("(?i)(?<![A-Z0-9])[A-Z2-7]{16,64}(?![A-Z0-9])")
        continuous.findAll(text).forEach { match ->
            val normalized = normalizeBase32(match.value)
            if (isPlausibleBase32(normalized)) return normalized
        }

        return null
    }

    private fun normalizeBase32(value: String): String =
        value.replace(Regex("[\\s-]"), "").uppercase(Locale.US)

    private fun isPlausibleBase32(value: String): Boolean =
        value.length >= 16 && value.length <= 64 &&
            value.all { it in 'A'..'Z' || it in '2'..'7' }

    private fun base32Decode(value: String): ByteArray? {
        if (!isPlausibleBase32(value)) return null

        val alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"
        val output = ArrayList<Byte>()
        var buffer = 0
        var bitsLeft = 0

        for (char in value) {
            val index = alphabet.indexOf(char)
            if (index < 0) return null
            buffer = (buffer shl 5) or index
            bitsLeft += 5
            if (bitsLeft >= 8) {
                bitsLeft -= 8
                output.add(((buffer shr bitsLeft) and 0xff).toByte())
            }
        }

        return output.toByteArray()
    }
}

class CopyReceiver : android.content.BroadcastReceiver() {
    companion object {
        const val ACTION_CODE = "com.tetocode.contestcodeshare.COPY_CODE"
        const val ACTION_LINK = "com.tetocode.contestcodeshare.COPY_LINK"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val value = intent.getStringExtra("value") ?: return
        val label = if (intent.action == ACTION_CODE) "رمز 2FA" else "رابط 2FA"

        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText(label, value))
    }
}
