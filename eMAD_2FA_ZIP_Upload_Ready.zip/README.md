# eMAD 2FA — ZIP Upload Version

هذه النسخة مصممة بحيث ترفع **ملف ZIP واحد فقط** إلى مستودع GitHub.

## طريقة الاستخدام

1. أنشئ Repository جديد.
2. ارفع ملف المشروع ZIP فقط إلى المستودع.
3. اعمل Commit.
4. افتح **Actions**.
5. اختر **Build APK from ZIP**.
6. اضغط **Run workflow**.

الـWorkflow سيقوم تلقائيًا بـ:
- العثور على ملف ZIP.
- فك الضغط.
- البحث عن `settings.gradle` أو `settings.gradle.kts`.
- تحديد مجلد المشروع تلقائيًا حتى لو كان المشروع داخل مجلد فرعي داخل ZIP.
- إعداد Java 17 وGradle.
- بناء APK.
- رفع APK في Artifacts.

> مهم: يجب أن يحتوي الـZIP على مشروع Android كامل، وليس APK فقط.
