package com.tetocode.contestcodeshare

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri

class ShareReceiverActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val sharedText = intent?.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
        val sharedUri = intent?.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)?.toString().orEmpty()
        val input = if (sharedText.isNotBlank()) sharedText else sharedUri

        if (input.isNotBlank()) {
            NotificationHelper.show(this, input)
        }

        finishAndRemoveTask()
    }
}
